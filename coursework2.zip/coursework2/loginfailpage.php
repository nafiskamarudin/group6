<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta http-equiv="refresh" content="3;URL=index.php" />
</head>
<body background ="image\Grey-And-White-Background-0-items-0-client-centre.jpg">

<body>

<div class="header">
			<div>
				<div align="center"></div>

<form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
 
<blockquote>
  <blockquote>
    <blockquote>
      <blockquote>
        <blockquote>
          <blockquote>
            <blockquote>
              <blockquote>
                <blockquote>&nbsp;</blockquote>
              </blockquote>
            </blockquote>
          </blockquote>
        </blockquote>
      </blockquote>
    </blockquote>
  </blockquote>
</blockquote>
<h1 align="center">YOUR USERNAME AND PASSWORD ARE INCORRECT.</h1>
<p align="center">&nbsp;</p>
<h2 align="center">PLEASE LOGIN AGAIN :)</h2>
</body>
</html>
